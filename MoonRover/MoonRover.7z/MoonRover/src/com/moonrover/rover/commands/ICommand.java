package com.moonrover.rover.commands;

import com.moonrover.rover.MoonRover;

public interface  ICommand {

    public void execute(final MoonRover rover);
}
